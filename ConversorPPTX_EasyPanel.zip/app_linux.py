from flask import Flask, request, render_template, send_file, flash, redirect, url_for
from werkzeug.utils import secure_filename
import os
import tempfile
import shutil
import subprocess
from fpdf import FPDF
from PIL import Image, ImageStat
import time

app = Flask(__name__)
app.secret_key = 'your-secret-key-here-change-this'  # Change this to a random secret key
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max file size

UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'output'
ALLOWED_EXTENSIONS = {'pptx', 'ppt'}

# Create directories if they don't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def convert_pptx_to_pdf_linux(pptx_path, pdf_path):
    """Convert PPTX to PDF using LibreOffice headless mode"""
    try:
        # Use LibreOffice to convert PPTX to PDF
        cmd = [
            'soffice',
            '--headless',
            '--convert-to', 'pdf',
            '--outdir', os.path.dirname(pdf_path),
            pptx_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0:
            # LibreOffice creates PDF with same name as input file
            expected_pdf = os.path.join(
                os.path.dirname(pdf_path),
                os.path.splitext(os.path.basename(pptx_path))[0] + '.pdf'
            )
            
            if os.path.exists(expected_pdf):
                # Rename to desired output path if different
                if expected_pdf != pdf_path:
                    shutil.move(expected_pdf, pdf_path)
                return True
        
        print(f"LibreOffice conversion failed: {result.stderr}")
        return False
        
    except subprocess.TimeoutExpired:
        print("LibreOffice conversion timed out")
        return False
    except Exception as e:
        print(f"Error converting PPTX to PDF: {e}")
        return False

def pdf_to_images_linux(pdf_path, output_dir):
    """Convert PDF pages to images using pdftoppm"""
    try:
        # Use pdftoppm to convert PDF to PNG images
        cmd = [
            'pdftoppm',
            '-png',
            '-r', '200',  # 200 DPI for good quality
            pdf_path,
            os.path.join(output_dir, 'slide')
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        
        if result.returncode == 0:
            # Get list of generated images
            image_files = [f for f in os.listdir(output_dir) if f.startswith('slide') and f.endswith('.png')]
            image_files.sort()
            
            image_paths = [os.path.join(output_dir, f) for f in image_files]
            return image_paths
        
        print(f"pdftoppm conversion failed: {result.stderr}")
        return []
        
    except subprocess.TimeoutExpired:
        print("PDF to images conversion timed out")
        return []
    except Exception as e:
        print(f"Error converting PDF to images: {e}")
        return []

def get_dominant_color(image_path, sample_size=100):
    """Extract dominant background color from image"""
    try:
        img = Image.open(image_path)
        img = img.convert("RGB")
        width, height = img.size

        # Sample pixels from corners and edges
        pixels = []
        # Top-left corner
        for x in range(min(sample_size, width // 2)):
            for y in range(min(sample_size, height // 2)):
                pixels.append(img.getpixel((x, y)))
        # Top-right corner
        for x in range(max(0, width - sample_size), width):
            for y in range(min(sample_size, height // 2)):
                pixels.append(img.getpixel((x, y)))
        # Bottom-left corner
        for x in range(min(sample_size, width // 2)):
            for y in range(max(0, height - sample_size), height):
                pixels.append(img.getpixel((x, y)))
        # Bottom-right corner
        for x in range(max(0, width - sample_size), width):
            for y in range(max(0, height - sample_size), height):
                pixels.append(img.getpixel((x, y)))

        if not pixels:
            return (255, 255, 255)

        avg_r = sum(p[0] for p in pixels) // len(pixels)
        avg_g = sum(p[1] for p in pixels) // len(pixels)
        avg_b = sum(p[2] for p in pixels) // len(pixels)

        return (avg_r, avg_g, avg_b)
    except Exception as e:
        print(f"Error getting dominant color: {e}")
        return (255, 255, 255)

def is_irrelevant_image(image_path, blank_threshold=240, blank_min_pixels=0.99, content_threshold=1000, min_file_size=100000):
    """Check if image is mostly blank or irrelevant"""
    try:
        file_size = os.path.getsize(image_path)
        if file_size < min_file_size:
            return True
        
        img = Image.open(image_path)
        grayscale_img = img.convert("L")
        width, height = grayscale_img.size
        total_pixels = width * height
        white_pixels = 0
        
        for pixel in grayscale_img.getdata():
            if pixel > blank_threshold:
                white_pixels += 1
                
        if (white_pixels / total_pixels) >= blank_min_pixels:
            return True

        stat = ImageStat.Stat(img)
        if sum(stat.var) < content_threshold:
            return True

        return False
    except Exception as e:
        print(f"Error checking irrelevant image: {e}")
        return False

def combine_images_to_pdf(image_paths, output_pdf_path, images_per_page=3, background_color_rgb=(254, 254, 254)):
    """Combine images into a single PDF with specified layout"""
    pdf = FPDF(unit="mm", format="A4")
    pdf.set_auto_page_break(auto=False)

    # Filter out irrelevant images
    filtered_image_paths = [path for path in image_paths if not is_irrelevant_image(path)]

    a4_width_mm = 210
    a4_height_mm = 297
    margin_mm = 10

    available_width = a4_width_mm - (2 * margin_mm)
    available_height = a4_height_mm - (2 * margin_mm)

    for i in range(0, len(filtered_image_paths), images_per_page):
        pdf.add_page()
        pdf.set_fill_color(background_color_rgb[0], background_color_rgb[1], background_color_rgb[2])
        pdf.rect(0, 0, a4_width_mm, a4_height_mm, 'F')

        images_in_current_page = filtered_image_paths[i:i + images_per_page]
        slot_height = available_height / images_per_page

        for j, image_path in enumerate(images_in_current_page):
            img = Image.open(image_path)
            original_width, original_height = img.size
            aspect_ratio = original_height / original_width

            new_width_mm = available_width
            new_height_mm = new_width_mm * aspect_ratio

            if new_height_mm > slot_height:
                new_height_mm = slot_height
                new_width_mm = new_height_mm / aspect_ratio

            x_pos = margin_mm + (available_width - new_width_mm) / 2
            y_pos = margin_mm + (j * slot_height) + (slot_height - new_height_mm) / 2

            pdf.image(image_path, x=x_pos, y=y_pos, w=new_width_mm, h=new_height_mm)

    pdf.output(output_pdf_path)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('Nenhum arquivo selecionado')
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        flash('Nenhum arquivo selecionado')
        return redirect(request.url)
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        timestamp = str(int(time.time()))
        filename = f"{timestamp}_{filename}"
        
        # Save uploaded file
        upload_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(upload_path)
        
        try:
            # Create temporary directory for processing
            with tempfile.TemporaryDirectory() as temp_dir:
                # Convert PPTX to PDF
                temp_pdf_path = os.path.join(temp_dir, "temp.pdf")
                if not convert_pptx_to_pdf_linux(upload_path, temp_pdf_path):
                    flash('Erro ao converter PPTX para PDF. Verifique se o LibreOffice está instalado.')
                    return redirect(url_for('index'))
                
                # Convert PDF to images
                image_paths = pdf_to_images_linux(temp_pdf_path, temp_dir)
                if not image_paths:
                    flash('Erro ao converter PDF para imagens. Verifique se o poppler-utils está instalado.')
                    return redirect(url_for('index'))
                
                # Get background color from first image
                background_color = get_dominant_color(image_paths[0]) if image_paths else (254, 254, 254)
                
                # Combine images into final PDF
                output_filename = f"converted_{timestamp}.pdf"
                output_path = os.path.join(OUTPUT_FOLDER, output_filename)
                combine_images_to_pdf(image_paths, output_path, images_per_page=3, background_color_rgb=background_color)
                
                # Clean up uploaded file
                os.remove(upload_path)
                
                flash('Conversão realizada com sucesso!')
                return send_file(output_path, as_attachment=True, download_name=f"converted_{filename.rsplit('.', 1)[0]}.pdf")
                
        except Exception as e:
            flash(f'Erro durante o processamento: {str(e)}')
            return redirect(url_for('index'))
    
    flash('Tipo de arquivo não permitido. Use apenas .pptx ou .ppt')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000)

