#!/bin/bash

# Script para instalar dependências no servidor Ubuntu
# Para uso com EasyPanel

echo "=========================================="
echo "Instalando dependências para Conversor PPTX"
echo "=========================================="

# Atualizar sistema
echo "Atualizando sistema..."
apt-get update

# Instalar dependências do sistema
echo "Instalando dependências do sistema..."
apt-get install -y \
    python3 \
    python3-pip \
    libreoffice \
    poppler-utils \
    fonts-liberation \
    fonts-dejavu-core \
    git \
    curl

# Verificar instalações
echo "Verificando instalações..."

echo "Python3 version:"
python3 --version

echo "LibreOffice version:"
soffice --version

echo "pdftoppm version:"
pdftoppm -v

echo "pip3 version:"
pip3 --version

echo "=========================================="
echo "Dependências instaladas com sucesso!"
echo "=========================================="

# Instalar dependências Python
echo "Instalando dependências Python..."
pip3 install Flask==2.3.3 Werkzeug==2.3.7 fpdf2==2.7.6 Pillow==10.0.1 gunicorn==21.2.0

echo "Instalação concluída!"

